﻿namespace skin
{
    partial class PrescribeMedicine
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblPatient = new Label();
            lblMedicineName = new Label();
            lblDosage = new Label();
            cmbPatients = new ComboBox();
            txtMedicineName = new TextBox();
            txtDosage = new TextBox();
            btnPrescribe = new Button();
            SuspendLayout();
            // 
            // lblPatient
            // 
            lblPatient.AutoSize = true;
            lblPatient.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblPatient.Location = new Point(130, 140);
            lblPatient.Name = "lblPatient";
            lblPatient.Size = new Size(68, 23);
            lblPatient.TabIndex = 0;
            lblPatient.Text = "Patient:";
            // 
            // cmbPatients
            // 
            cmbPatients.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbPatients.FormattingEnabled = true;
            cmbPatients.Location = new Point(235, 131);
            cmbPatients.Name = "cmbPatients";
            cmbPatients.Size = new Size(622, 28);
            cmbPatients.TabIndex = 1;
            // 
            // lblMedicineName
            // 
            lblMedicineName.AutoSize = true;
            lblMedicineName.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblMedicineName.Location = new Point(90, 210);
            lblMedicineName.Name = "lblMedicineName";
            lblMedicineName.Size = new Size(133, 23);
            lblMedicineName.TabIndex = 2;
            lblMedicineName.Text = "Medicine Name:";
            // 
            // txtMedicineName
            // 
            txtMedicineName.Location = new Point(235, 199);
            txtMedicineName.Multiline = false;
            txtMedicineName.Name = "txtMedicineName";
            txtMedicineName.PlaceholderText = "Enter Medicine Name";
            txtMedicineName.Size = new Size(622, 30);
            txtMedicineName.TabIndex = 3;
            // 
            // lblDosage
            // 
            lblDosage.AutoSize = true;
            lblDosage.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblDosage.Location = new Point(145, 275);
            lblDosage.Name = "lblDosage";
            lblDosage.Size = new Size(76, 23);
            lblDosage.TabIndex = 4;
            lblDosage.Text = "Dosage:";
            // 
            // txtDosage
            // 
            txtDosage.Location = new Point(235, 265);
            txtDosage.Multiline = false;
            txtDosage.Name = "txtDosage";
            txtDosage.PlaceholderText = "Enter Dosage";
            txtDosage.Size = new Size(622, 30);
            txtDosage.TabIndex = 5;
            // 
            // btnPrescribe
            // 
            btnPrescribe.BackColor = Color.FromArgb(0, 192, 0);
            btnPrescribe.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnPrescribe.Location = new Point(235, 340);
            btnPrescribe.Name = "btnPrescribe";
            btnPrescribe.Size = new Size(622, 50);
            btnPrescribe.TabIndex = 6;
            btnPrescribe.Text = "Prescribe";
            btnPrescribe.UseVisualStyleBackColor = false;
            btnPrescribe.Click += BtnPrescribe_Click;
            // 
            // PrescribeMedicine
            // 
            ClientSize = new Size(1096, 652);
            Controls.Add(lblPatient);
            Controls.Add(cmbPatients);
            Controls.Add(lblMedicineName);
            Controls.Add(txtMedicineName);
            Controls.Add(lblDosage);
            Controls.Add(txtDosage);
            Controls.Add(btnPrescribe);
            Name = "PrescribeMedicine";
            Text = "Prescribe Medicine";
            Load += PrescribeMedicine_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblPatient;
        private System.Windows.Forms.ComboBox cmbPatients;
        private System.Windows.Forms.Label lblMedicineName;
        private System.Windows.Forms.TextBox txtMedicineName;
        private System.Windows.Forms.Label lblDosage;
        private System.Windows.Forms.TextBox txtDosage;
        private System.Windows.Forms.Button btnPrescribe;
    }
}
