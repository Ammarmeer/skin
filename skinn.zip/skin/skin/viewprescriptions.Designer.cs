﻿using static System.Net.Mime.MediaTypeNames;
using System.Windows.Forms;

namespace skin
{
    partial class ViewPrescriptions
    {
        private System.ComponentModel.IContainer components = null;
        private DataGridView dgvPrescriptions;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            dgvPrescriptions = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgvPrescriptions).BeginInit();
            SuspendLayout();
            // 
            // dgvPrescriptions
            // 
            dgvPrescriptions.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPrescriptions.Location = new System.Drawing.Point(12, 12);
            dgvPrescriptions.Name = "dgvPrescriptions";
            dgvPrescriptions.RowHeadersWidth = 51;
            dgvPrescriptions.RowTemplate.Height = 29;
            dgvPrescriptions.Size = new System.Drawing.Size(760, 426);
            dgvPrescriptions.TabIndex = 0;
            // 
            // ViewPrescriptions
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(784, 450);
            Controls.Add(dgvPrescriptions);
            Name = "ViewPrescriptions";
            Text = "View Prescriptions";
            Load += ViewPrescriptions_Load;
            ((System.ComponentModel.ISupportInitialize)dgvPrescriptions).EndInit();
            ResumeLayout(false);
        }
    }
}
