﻿using System;
using System.Windows.Forms;

namespace skin
{
    public partial class admin : Form
    {
        public admin()
        {
            InitializeComponent();
        }

        // Method that runs when the form loads
        private void admin_Load(object sender, EventArgs e)
        {
            // Perform any initialization tasks here
            MessageBox.Show("Welcome to the Admin Dashboard!", "Admin Panel", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void BtnManageUsers_Click(object sender, EventArgs e)
        {
            ManageUsers manageUsersForm = new ManageUsers();
            manageUsersForm.Show();
        }

        private void BtnManageAppointments_Click(object sender, EventArgs e)
        {
            ManageAppointments manageAppointmentsForm = new ManageAppointments();
            manageAppointmentsForm.Show();
        }

        private void BtnViewActivity_Click(object sender, EventArgs e)
        {
            ViewActivity viewActivityForm = new ViewActivity();
            viewActivityForm.Show();
        }
    }
}
