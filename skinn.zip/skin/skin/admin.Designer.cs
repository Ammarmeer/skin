﻿namespace skin
{
    partial class admin
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnManageUsers = new Button();
            btnManageAppointments = new Button();
            btnViewActivity = new Button();
            SuspendLayout();
            // 
            // btnManageUsers
            // 
            btnManageUsers.BackColor = Color.Navy;
            btnManageUsers.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btnManageUsers.ForeColor = Color.White;
            btnManageUsers.Location = new Point(12, 197);
            btnManageUsers.Name = "btnManageUsers";
            btnManageUsers.Size = new Size(318, 180);
            btnManageUsers.TabIndex = 0;
            btnManageUsers.Text = "Manage Users";
            btnManageUsers.UseVisualStyleBackColor = false;
            btnManageUsers.Click += BtnManageUsers_Click;
            // 
            // btnManageAppointments
            // 
            btnManageAppointments.BackColor = SystemColors.ActiveCaption;
            btnManageAppointments.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btnManageAppointments.ForeColor = SystemColors.ActiveCaptionText;
            btnManageAppointments.Location = new Point(377, 197);
            btnManageAppointments.Name = "btnManageAppointments";
            btnManageAppointments.Size = new Size(294, 180);
            btnManageAppointments.TabIndex = 1;
            btnManageAppointments.Text = "Manage Appointments";
            btnManageAppointments.UseVisualStyleBackColor = false;
            btnManageAppointments.Click += BtnManageAppointments_Click;
            // 
            // btnViewActivity
            // 
            btnViewActivity.BackColor = Color.FromArgb(0, 192, 0);
            btnViewActivity.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold);
            btnViewActivity.ForeColor = SystemColors.ActiveCaptionText;
            btnViewActivity.Location = new Point(714, 197);
            btnViewActivity.Name = "btnViewActivity";
            btnViewActivity.Size = new Size(297, 180);
            btnViewActivity.TabIndex = 2;
            btnViewActivity.Text = "View Activity";
            btnViewActivity.UseVisualStyleBackColor = false;
            btnViewActivity.Click += BtnViewActivity_Click;
            // 
            // admin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1038, 605);
            Controls.Add(btnViewActivity);
            Controls.Add(btnManageAppointments);
            Controls.Add(btnManageUsers);
            Name = "admin";
            Text = "Admin Dashboard";
            Load += admin_Load;
            ResumeLayout(false);
        }

        private System.Windows.Forms.Button btnManageUsers;
        private System.Windows.Forms.Button btnManageAppointments;
        private System.Windows.Forms.Button btnViewActivity;
    }
}
