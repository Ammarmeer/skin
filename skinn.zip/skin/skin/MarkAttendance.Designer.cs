﻿namespace skin
{
    partial class MarkAttendance
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            dgvAttendance = new DataGridView();
            btnMarkPresent = new Button();
            btnMarkAbsent = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvAttendance).BeginInit();
            SuspendLayout();
            // 
            // dgvAttendance
            // 
            dgvAttendance.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAttendance.Location = new Point(12, 12);
            dgvAttendance.Name = "dgvAttendance";
            dgvAttendance.RowHeadersWidth = 51;
            dgvAttendance.Size = new Size(600, 300);
            dgvAttendance.TabIndex = 0;
            // 
            // btnMarkPresent
            // 
            btnMarkPresent.Location = new Point(12, 330);
            btnMarkPresent.Name = "btnMarkPresent";
            btnMarkPresent.Size = new Size(150, 30);
            btnMarkPresent.TabIndex = 1;
            btnMarkPresent.Text = "Mark Present";
            btnMarkPresent.UseVisualStyleBackColor = true;
            btnMarkPresent.Click += BtnMarkPresent_Click;
            // 
            // btnMarkAbsent
            // 
            btnMarkAbsent.Location = new Point(180, 330);
            btnMarkAbsent.Name = "btnMarkAbsent";
            btnMarkAbsent.Size = new Size(150, 30);
            btnMarkAbsent.TabIndex = 2;
            btnMarkAbsent.Text = "Mark Absent";
            btnMarkAbsent.UseVisualStyleBackColor = true;
            btnMarkAbsent.Click += BtnMarkAbsent_Click;
            // 
            // MarkAttendance
            // 
            ClientSize = new Size(624, 441);
            Controls.Add(btnMarkAbsent);
            Controls.Add(btnMarkPresent);
            Controls.Add(dgvAttendance);
            Name = "MarkAttendance";
            Text = "Mark Attendance";
            Load += MarkAttendance_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAttendance).EndInit();
            ResumeLayout(false);
        }

        private System.Windows.Forms.DataGridView dgvAttendance;
        private System.Windows.Forms.Button btnMarkPresent;
        private System.Windows.Forms.Button btnMarkAbsent;
    }
}
