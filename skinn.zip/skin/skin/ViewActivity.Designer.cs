﻿namespace skin
{
    partial class ViewActivity
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvActivity = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvActivity)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvActivity
            // 
            this.dgvActivity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvActivity.Location = new System.Drawing.Point(12, 12);
            this.dgvActivity.Name = "dgvActivity";
            this.dgvActivity.RowHeadersWidth = 51;
            this.dgvActivity.RowTemplate.Height = 29;
            this.dgvActivity.Size = new System.Drawing.Size(760, 400);
            this.dgvActivity.TabIndex = 0;
            // 
            // ViewActivity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 441);
            this.Controls.Add(this.dgvActivity);
            this.Name = "ViewActivity";
            this.Text = "View Activity";
            this.Load += new System.EventHandler(this.ViewActivity_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvActivity)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.DataGridView dgvActivity;
    }
}
