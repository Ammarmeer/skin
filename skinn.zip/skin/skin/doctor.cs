﻿using System;
using System.Windows.Forms;

namespace skin
{
    public partial class doctor : Form
    {
        private readonly int doctorId;

        public doctor(int doctorId)
        {
            InitializeComponent();
            this.doctorId = doctorId; // Assign the doctor ID
        }

        // Event for viewing appointments
        private void BtnViewAppointments_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate the doctor ID
                if (doctorId <= 0)
                {
                    MessageBox.Show("Invalid Doctor ID. Please log in again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Open the ViewAppointments form for this doctor
                ViewAppointments viewAppointmentsForm = new ViewAppointments(null, doctorId);
                viewAppointmentsForm.ShowDialog(); // Use ShowDialog for modal behavior
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening View Appointments form: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event for marking attendance
        private void BtnMarkAttendance_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate the doctor ID
                if (doctorId <= 0)
                {
                    MessageBox.Show("Invalid Doctor ID. Please log in again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Open the MarkAttendance form for this doctor
                using (MarkAttendance markAttendanceForm = new MarkAttendance(doctorId))
                {
                    markAttendanceForm.ShowDialog(); // Use ShowDialog for modal interaction
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while opening the Mark Attendance form: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        // Event for prescribing medicine
        private void BtnPrescribeMedicine_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate the doctor ID
                if (doctorId <= 0)
                {
                    MessageBox.Show("Invalid Doctor ID. Please log in again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Open the PrescribeMedicine form for this doctor
                PrescribeMedicine prescribeMedicineForm = new PrescribeMedicine(doctorId);
                prescribeMedicineForm.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening Prescribe Medicine form: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Form Load event
        private void doctor_Load(object sender, EventArgs e)
        {
            try
            {
                // Display a welcome message for the doctor
                MessageBox.Show($"Welcome, Doctor ID: {doctorId}!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error during form load: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
