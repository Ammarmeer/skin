﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace skin
{
    public partial class MarkAttendance : Form
    {
        private readonly string connectionString = "Data Source=DESKTOP-THSOQHE\\SQLEXPRESS;Initial Catalog=skincare;Integrated Security=True;Trust Server Certificate=True";
        private readonly int doctorId;

        // Constructor accepting a doctor ID
        public MarkAttendance(int doctorId)
        {
            InitializeComponent();
            this.doctorId = doctorId;
            LoadAttendanceData(); // Load attendance data on form initialization
        }

        // Load attendance data for the specific doctor from the Attendance table
        private void LoadAttendanceData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            u.UserID AS [Doctor ID], 
                            u.Name AS [Doctor Name], 
                            COALESCE(CONVERT(VARCHAR, a.AttendanceDate, 120), '-') AS [Attendance Date], 
                            COALESCE(a.Status, '-') AS [Status]
                        FROM 
                            Users u
                        LEFT JOIN 
                            Attendance a ON u.UserID = a.UserID
                        WHERE 
                            u.Role = 'Doctor' AND u.UserID = @DoctorID
                        ORDER BY 
                            a.AttendanceDate DESC";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@DoctorID", doctorId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvAttendance.DataSource = dataTable;
                    dgvAttendance.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Auto-resize columns
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading attendance data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Button event for marking "Present"
        private void BtnMarkPresent_Click(object sender, EventArgs e)
        {
            UpdateAttendance("Present");
        }

        // Button event for marking "Absent"
        private void BtnMarkAbsent_Click(object sender, EventArgs e)
        {
            UpdateAttendance("Absent");
        }

        // Update attendance for the specific doctor
        private void UpdateAttendance(string status)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        IF NOT EXISTS (
                            SELECT 1 
                            FROM Attendance 
                            WHERE UserID = @DoctorID AND AttendanceDate = CAST(GETDATE() AS DATE)
                        )
                        BEGIN
                            INSERT INTO Attendance (UserID, AttendanceDate, Status)
                            VALUES (@DoctorID, GETDATE(), @Status)
                        END
                        ELSE
                        BEGIN
                            UPDATE Attendance
                            SET Status = @Status
                            WHERE UserID = @DoctorID AND AttendanceDate = CAST(GETDATE() AS DATE)
                        END";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@DoctorID", doctorId);
                    cmd.Parameters.AddWithValue("@Status", status);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show($"Attendance marked as {status}.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAttendanceData(); // Refresh data after update
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error updating attendance: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Form Load event
        private void MarkAttendance_Load(object sender, EventArgs e)
        {
            LoadAttendanceData(); // Load attendance data when the form loads
            MessageBox.Show("Welcome to the Attendance Panel.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
