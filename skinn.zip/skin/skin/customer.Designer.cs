﻿namespace skin
{
    partial class customer
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblWelcome = new Label();
            btnViewAppointments = new Button();
            btnViewProfile = new Button();
            btnLogout = new Button();
            btnViewPrescriptions = new Button();
            SuspendLayout();
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblWelcome.Location = new Point(306, 40);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(251, 32);
            lblWelcome.TabIndex = 0;
            lblWelcome.Text = "Welcome, Customer!";
            // 
            // btnViewAppointments
            // 
            btnViewAppointments.BackColor = Color.FromArgb(0, 64, 0);
            btnViewAppointments.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnViewAppointments.ForeColor = Color.White;
            btnViewAppointments.Location = new Point(50, 171);
            btnViewAppointments.Name = "btnViewAppointments";
            btnViewAppointments.Size = new Size(200, 158);
            btnViewAppointments.TabIndex = 1;
            btnViewAppointments.Text = "View Appointments";
            btnViewAppointments.UseVisualStyleBackColor = false;
            btnViewAppointments.Click += BtnViewAppointments_Click;
            // 
            // btnViewProfile
            // 
            btnViewProfile.BackColor = Color.Navy;
            btnViewProfile.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnViewProfile.ForeColor = Color.White;
            btnViewProfile.Location = new Point(290, 171);
            btnViewProfile.Name = "btnViewProfile";
            btnViewProfile.Size = new Size(200, 158);
            btnViewProfile.TabIndex = 2;
            btnViewProfile.Text = "View Profile";
            btnViewProfile.UseVisualStyleBackColor = false;
            btnViewProfile.Click += BtnViewProfile_Click;
            // 
            // btnViewPrescriptions
            // 
            btnViewPrescriptions.BackColor = Color.Teal;
            btnViewPrescriptions.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnViewPrescriptions.ForeColor = Color.White;
            btnViewPrescriptions.Location = new Point(530, 171);
            btnViewPrescriptions.Name = "btnViewPrescriptions";
            btnViewPrescriptions.Size = new Size(200, 158);
            btnViewPrescriptions.TabIndex = 4;
            btnViewPrescriptions.Text = "View Prescriptions";
            btnViewPrescriptions.UseVisualStyleBackColor = false;
            btnViewPrescriptions.Click += BtnViewPrescriptions_Click;
            // 
            // btnLogout
            // 
            btnLogout.BackColor = Color.Purple;
            btnLogout.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnLogout.ForeColor = Color.White;
            btnLogout.Location = new Point(290, 350);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(200, 60);
            btnLogout.TabIndex = 3;
            btnLogout.Text = "Logout";
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += BtnLogout_Click;
            // 
            // customer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(811, 495);
            Controls.Add(btnViewPrescriptions);
            Controls.Add(btnLogout);
            Controls.Add(btnViewProfile);
            Controls.Add(btnViewAppointments);
            Controls.Add(lblWelcome);
            Name = "customer";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Customer Dashboard";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Button btnViewAppointments;
        private System.Windows.Forms.Button btnViewProfile;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnViewPrescriptions;
    }
}
