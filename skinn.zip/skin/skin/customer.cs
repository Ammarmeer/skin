﻿using System;
using System.Windows.Forms;

namespace skin
{
    public partial class customer : Form
    {
        private readonly int customerId; // Store the logged-in customer's ID

        public customer(int customerId)
        {
            InitializeComponent();
            this.customerId = customerId; // Receive customer ID from login form
        }

        // Event handler for "View Appointments" button
        private void BtnViewAppointments_Click(object sender, EventArgs e)
        {
            try
            {
                // Open the ViewAppointments form
                using (ViewAppointments viewAppointmentsForm = new ViewAppointments(customerId))
                {
                    viewAppointmentsForm.ShowDialog(); // Use ShowDialog to keep it modal
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening View Appointments form: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for "View Profile" button
        private void BtnViewProfile_Click(object sender, EventArgs e)
        {
            try
            {
                // Open the CustomerProfile form
                using (CustomerProfile customerProfileForm = new CustomerProfile(customerId))
                {
                    customerProfileForm.ShowDialog(); // Use ShowDialog to keep it modal
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening Customer Profile form: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for "View Prescriptions" button
        private void BtnViewPrescriptions_Click(object sender, EventArgs e)
        {
            try
            {
                // Open the ViewPrescriptions form
                using (ViewPrescriptions viewPrescriptionsForm = new ViewPrescriptions(customerId))
                {
                    viewPrescriptionsForm.ShowDialog(); // Use ShowDialog to keep it modal
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening View Prescriptions form: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Event handler for "Logout" button
        private void BtnLogout_Click(object sender, EventArgs e)
        {
            DialogResult confirmLogout = MessageBox.Show(
                "Are you sure you want to log out?",
                "Logout Confirmation",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirmLogout == DialogResult.Yes)
            {
                try
                {
                    this.Hide(); // Hide the current form
                    using (Form1 loginForm = new Form1()) // Assuming Form1 is the login form
                    {
                        loginForm.ShowDialog();
                    }
                    this.Close(); // Close the dashboard after logout
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error during logout: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
