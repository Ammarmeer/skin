﻿namespace skin
{
    partial class doctor
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnViewAppointments = new Button();
            btnMarkAttendance = new Button();
            btnPrescribeMedicine = new Button();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnViewAppointments
            // 
            btnViewAppointments.BackColor = Color.Brown;
            btnViewAppointments.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnViewAppointments.Location = new Point(39, 199);
            btnViewAppointments.Name = "btnViewAppointments";
            btnViewAppointments.Size = new Size(200, 195);
            btnViewAppointments.TabIndex = 0;
            btnViewAppointments.Text = "View Appointments";
            btnViewAppointments.UseVisualStyleBackColor = false;
            btnViewAppointments.Click += BtnViewAppointments_Click;
            // 
            // btnMarkAttendance
            // 
            btnMarkAttendance.BackColor = Color.DarkGreen;
            btnMarkAttendance.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnMarkAttendance.ForeColor = SystemColors.ControlLightLight;
            btnMarkAttendance.Location = new Point(285, 199);
            btnMarkAttendance.Name = "btnMarkAttendance";
            btnMarkAttendance.Size = new Size(200, 195);
            btnMarkAttendance.TabIndex = 1;
            btnMarkAttendance.Text = "Mark Attendance";
            btnMarkAttendance.UseVisualStyleBackColor = false;
            btnMarkAttendance.Click += BtnMarkAttendance_Click;
            // 
            // btnPrescribeMedicine
            // 
            btnPrescribeMedicine.BackColor = Color.FromArgb(0, 0, 192);
            btnPrescribeMedicine.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnPrescribeMedicine.ForeColor = SystemColors.ControlLightLight;
            btnPrescribeMedicine.Location = new Point(536, 199);
            btnPrescribeMedicine.Name = "btnPrescribeMedicine";
            btnPrescribeMedicine.Size = new Size(200, 195);
            btnPrescribeMedicine.TabIndex = 2;
            btnPrescribeMedicine.Text = "Prescribe Medicine";
            btnPrescribeMedicine.UseVisualStyleBackColor = false;
            btnPrescribeMedicine.Click += BtnPrescribeMedicine_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(253, 92);
            label1.Name = "label1";
            label1.Size = new Size(318, 41);
            label1.TabIndex = 3;
            label1.Text = "DOCTOR DASHBOARD";
            // 
            // doctor
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(783, 561);
            Controls.Add(label1);
            Controls.Add(btnPrescribeMedicine);
            Controls.Add(btnMarkAttendance);
            Controls.Add(btnViewAppointments);
            Name = "doctor";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Doctor Dashboard";
            Load += doctor_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Button btnViewAppointments;
        private System.Windows.Forms.Button btnMarkAttendance;
        private System.Windows.Forms.Button btnPrescribeMedicine;
        private Label label1;
    }
}
