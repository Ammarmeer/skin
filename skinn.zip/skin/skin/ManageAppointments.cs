﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace skin
{
    public partial class ManageAppointments : Form
    {
        private readonly string connectionString = "Data Source=DESKTOP-THSOQHE\\SQLEXPRESS;Initial Catalog=skincare;Integrated Security=True;Trust Server Certificate=True";

        public ManageAppointments()
        {
            InitializeComponent();
        }

        private void ManageAppointments_Load(object sender, EventArgs e)
        {
            PopulateUserDropdown();
            PopulateDoctorDropdown();
            LoadAppointments();
        }

        // Populate the User dropdown with customers (Role = 'Customer') from the Users table
        private void PopulateUserDropdown()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT UserID, Name FROM Users WHERE Role = 'Customer'";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable userTable = new DataTable();
                    adapter.Fill(userTable);

                    cboUser.DisplayMember = "Name";
                    cboUser.ValueMember = "UserID";
                    cboUser.DataSource = userTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading customers: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Populate the Doctor dropdown with doctors (Role = 'Doctor') from the Users table
        private void PopulateDoctorDropdown()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT UserID, Name FROM Users WHERE Role = 'Doctor'";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable doctorTable = new DataTable();
                    adapter.Fill(doctorTable);

                    cboDoctor.DisplayMember = "Name";
                    cboDoctor.ValueMember = "UserID";
                    cboDoctor.DataSource = doctorTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading doctors: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Load appointments into the DataGridView
        private void LoadAppointments()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            a.AppointmentID, 
                            u.Name AS UserName, 
                            d.Name AS DoctorName, 
                            a.AppointmentDate 
                        FROM 
                            mappointment a
                        INNER JOIN Users u ON a.UserID = u.UserID AND u.Role = 'Customer'
                        INNER JOIN Users d ON a.DoctorID = d.UserID AND d.Role = 'Doctor'
                        ORDER BY a.AppointmentDate DESC";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvAppointments.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading appointments: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Add a new appointment
        private void BtnAddAppointment_Click(object sender, EventArgs e)
        {
            try
            {
                if (cboUser.SelectedValue == null || cboDoctor.SelectedValue == null)
                {
                    MessageBox.Show("Please select a valid customer and doctor.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                int userId = (int)cboUser.SelectedValue;
                int doctorId = (int)cboDoctor.SelectedValue;
                DateTime appointmentDate = dtpAppointmentDate.Value;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO mappointment (AppointmentDate, UserID, DoctorID) VALUES (@AppointmentDate, @UserID, @DoctorID)";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@AppointmentDate", appointmentDate);
                    cmd.Parameters.AddWithValue("@UserID", userId);
                    cmd.Parameters.AddWithValue("@DoctorID", doctorId);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Appointment added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAppointments();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding appointment: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Edit an existing appointment
        private void BtnEditAppointment_Click(object sender, EventArgs e)
        {
            if (dgvAppointments.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an appointment to edit.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int appointmentID = Convert.ToInt32(dgvAppointments.SelectedRows[0].Cells["AppointmentID"].Value);

            try
            {
                DateTime newDate = dtpAppointmentDate.Value;

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE mappointment SET AppointmentDate = @AppointmentDate WHERE AppointmentID = @AppointmentID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@AppointmentDate", newDate);
                    cmd.Parameters.AddWithValue("@AppointmentID", appointmentID);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Appointment updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAppointments();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating appointment: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Delete an appointment
        private void BtnDeleteAppointment_Click(object sender, EventArgs e)
        {
            if (dgvAppointments.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select an appointment to delete.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int appointmentID = Convert.ToInt32(dgvAppointments.SelectedRows[0].Cells["AppointmentID"].Value);

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "DELETE FROM mappointment WHERE AppointmentID = @AppointmentID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@AppointmentID", appointmentID);
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Appointment deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadAppointments();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting appointment: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cboDoctor_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Add logic if needed for the doctor dropdown selection change
        }
    }
}
