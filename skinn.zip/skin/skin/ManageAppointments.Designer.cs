﻿namespace skin
{
    partial class ManageAppointments
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            dgvAppointments = new DataGridView();
            btnAddAppointment = new Button();
            btnEditAppointment = new Button();
            btnDeleteAppointment = new Button();
            lblUser = new Label();
            cboUser = new ComboBox();
            lblDoctor = new Label();
            cboDoctor = new ComboBox();
            lblDate = new Label();
            dtpAppointmentDate = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)dgvAppointments).BeginInit();
            SuspendLayout();
            // 
            // dgvAppointments
            // 
            dgvAppointments.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAppointments.Location = new Point(12, 12);
            dgvAppointments.Name = "dgvAppointments";
            dgvAppointments.RowHeadersWidth = 51;
            dgvAppointments.Size = new Size(1110, 539);
            dgvAppointments.TabIndex = 0;
            // 
            // btnAddAppointment
            // 
            btnAddAppointment.BackColor = Color.Blue;
            btnAddAppointment.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold);
            btnAddAppointment.ForeColor = Color.White;
            btnAddAppointment.Location = new Point(319, 625);
            btnAddAppointment.Name = "btnAddAppointment";
            btnAddAppointment.Size = new Size(150, 65);
            btnAddAppointment.TabIndex = 8;
            btnAddAppointment.Text = "Add Appointment";
            btnAddAppointment.UseVisualStyleBackColor = false;
            btnAddAppointment.Click += BtnAddAppointment_Click;
            // 
            // btnEditAppointment
            // 
            btnEditAppointment.BackColor = Color.DarkSlateBlue;
            btnEditAppointment.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold);
            btnEditAppointment.ForeColor = Color.White;
            btnEditAppointment.Location = new Point(487, 625);
            btnEditAppointment.Name = "btnEditAppointment";
            btnEditAppointment.Size = new Size(150, 65);
            btnEditAppointment.TabIndex = 9;
            btnEditAppointment.Text = "Edit Appointment";
            btnEditAppointment.UseVisualStyleBackColor = false;
            btnEditAppointment.Click += BtnEditAppointment_Click;
            // 
            // btnDeleteAppointment
            // 
            btnDeleteAppointment.BackColor = Color.Teal;
            btnDeleteAppointment.Font = new Font("Segoe UI", 10.8F, FontStyle.Bold);
            btnDeleteAppointment.ForeColor = Color.White;
            btnDeleteAppointment.Location = new Point(655, 625);
            btnDeleteAppointment.Name = "btnDeleteAppointment";
            btnDeleteAppointment.Size = new Size(150, 65);
            btnDeleteAppointment.TabIndex = 10;
            btnDeleteAppointment.Text = "Delete Appointment";
            btnDeleteAppointment.UseVisualStyleBackColor = false;
            btnDeleteAppointment.Click += BtnDeleteAppointment_Click;
            // 
            // lblUser
            // 
            lblUser.AutoSize = true;
            lblUser.Location = new Point(154, 573);
            lblUser.Name = "lblUser";
            lblUser.Size = new Size(41, 20);
            lblUser.TabIndex = 1;
            lblUser.Text = "User:";
            // 
            // cboUser
            // 
            cboUser.DropDownStyle = ComboBoxStyle.DropDownList;
            cboUser.Font = new Font("Segoe UI", 10.8F);
            cboUser.FormattingEnabled = true;
            cboUser.Location = new Point(202, 570);
            cboUser.Name = "cboUser";
            cboUser.Size = new Size(200, 33);
            cboUser.TabIndex = 2;
            // 
            // lblDoctor
            // 
            lblDoctor.AutoSize = true;
            lblDoctor.Location = new Point(422, 573);
            lblDoctor.Name = "lblDoctor";
            lblDoctor.Size = new Size(58, 20);
            lblDoctor.TabIndex = 3;
            lblDoctor.Text = "Doctor:";
            // 
            // cboDoctor
            // 
            cboDoctor.DropDownStyle = ComboBoxStyle.DropDownList;
            cboDoctor.Font = new Font("Segoe UI", 10.8F);
            cboDoctor.FormattingEnabled = true;
            cboDoctor.Location = new Point(485, 570);
            cboDoctor.Name = "cboDoctor";
            cboDoctor.Size = new Size(200, 33);
            cboDoctor.TabIndex = 4;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Location = new Point(702, 573);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(44, 20);
            lblDate.TabIndex = 5;
            lblDate.Text = "Date:";
            // 
            // dtpAppointmentDate
            // 
            dtpAppointmentDate.CalendarFont = new Font("Segoe UI", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dtpAppointmentDate.Location = new Point(749, 570);
            dtpAppointmentDate.Name = "dtpAppointmentDate";
            dtpAppointmentDate.Size = new Size(200, 27);
            dtpAppointmentDate.TabIndex = 6;
            // 
            // ManageAppointments
            // 
            ClientSize = new Size(1134, 721);
            Controls.Add(dtpAppointmentDate);
            Controls.Add(lblDate);
            Controls.Add(cboDoctor);
            Controls.Add(lblDoctor);
            Controls.Add(cboUser);
            Controls.Add(lblUser);
            Controls.Add(btnDeleteAppointment);
            Controls.Add(btnEditAppointment);
            Controls.Add(btnAddAppointment);
            Controls.Add(dgvAppointments);
            Name = "ManageAppointments";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Manage Appointments";
            Load += ManageAppointments_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAppointments).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private DataGridView dgvAppointments;
        private Button btnAddAppointment;
        private Button btnEditAppointment;
        private Button btnDeleteAppointment;
        private Label lblUser;
        private ComboBox cboUser;
        private Label lblDoctor;
        private ComboBox cboDoctor;
        private Label lblDate;
        private DateTimePicker dtpAppointmentDate;
    }
}
