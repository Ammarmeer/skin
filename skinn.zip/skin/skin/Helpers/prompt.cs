﻿public static class Prompt
{
    public static string ShowDialog(string text, string caption)
    {
        Form prompt = new Form()
        {
            Width = 400,
            Height = 200,
            Text = caption,
            StartPosition = FormStartPosition.CenterScreen
        };
        Label textLabel = new Label() { Left = 20, Top = 20, Text = text };
        TextBox inputBox = new TextBox() { Left = 20, Top = 50, Width = 340 };
        Button confirmation = new Button() { Text = "OK", Left = 150, Width = 100, Top = 100 };
        confirmation.Click += (sender, e) => { prompt.Close(); };
        prompt.Controls.Add(inputBox);
        prompt.Controls.Add(confirmation);
        prompt.Controls.Add(textLabel);
        prompt.AcceptButton = confirmation;

        prompt.ShowDialog();
        return inputBox.Text;
    }
}
