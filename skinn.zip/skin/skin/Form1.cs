using System;
using System.Windows.Forms;
using Microsoft.Data.SqlClient; // For SQL Server connection

namespace skin
{
    public partial class Form1 : Form
    {
        private readonly string connectionString = "Data Source=DESKTOP-THSOQHE\\SQLEXPRESS;Initial Catalog=skincare;Integrated Security=True;Encrypt=True;Trust Server Certificate=True";

        public Form1()
        {
            InitializeComponent();
        }

        // Form Load Event
        private void Form1_Load(object sender, EventArgs e)
        {
            // Optional welcome message on form load
            MessageBox.Show("Welcome to the Login Form!", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Login Button Click Event
        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT Role, UserID FROM Users WHERE Name = @username AND Password = @password";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        string role = reader["Role"].ToString();
                        int userId = Convert.ToInt32(reader["UserID"]);

                        MessageBox.Show($"Welcome, {role}!", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        this.Hide();

                        // Navigate to the appropriate form based on role
                        if (role == "Admin")
                        {
                            admin adminForm = new admin();
                            adminForm.Show();
                        }
                        else if (role == "Doctor")
                        {
                            doctor doctorForm = new doctor(userId); // Pass the UserID as doctorId
                            doctorForm.Show();
                        }
                        else if (role == "Customer")
                        {
                            customer customerForm = new customer(userId); // Pass the UserID as customerId
                            customerForm.Show();
                        }
                        else
                        {
                            MessageBox.Show("Unknown role. Please contact the administrator.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            this.Show();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        // Clear Button Click Event
        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();
        }

        // Register Button Click Event
        private void BtnRegister_Click(object sender, EventArgs e)
        {
            // Open the Register form
            using (register registerForm = new register())
            {
                registerForm.ShowDialog();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            // Placeholder for label click event if needed
        }
    }
}
