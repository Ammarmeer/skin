﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace skin
{
    public partial class ViewPrescriptions : Form
    {
        private readonly string connectionString = "Data Source=DESKTOP-THSOQHE\\SQLEXPRESS;Initial Catalog=skincare;Integrated Security=True;Trust Server Certificate=True";
        private readonly int customerId; // The logged-in customer's ID

        public ViewPrescriptions(int customerId)
        {
            InitializeComponent();
            this.customerId = customerId; // Store the customer ID
        }

        private void ViewPrescriptions_Load(object sender, EventArgs e)
        {
            LoadPrescriptions(); // Load prescriptions when the form is loaded
        }

        private void LoadPrescriptions()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            p.PrescriptionID,
                            d.Name AS DoctorName,
                            p.MedicineName,
                            p.Dosage,
                            p.PrescriptionDate
                        FROM 
                            Prescriptions p
                        INNER JOIN Users d ON p.DoctorID = d.UserID
                        WHERE 
                            p.PatientID = @CustomerId
                        ORDER BY 
                            p.PrescriptionDate DESC";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@CustomerId", customerId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvPrescriptions.DataSource = dataTable; // Bind data to the DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading prescriptions: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
