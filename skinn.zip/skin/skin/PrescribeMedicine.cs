﻿using System;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace skin
{
    public partial class PrescribeMedicine : Form
    {
        private readonly string connectionString = "Data Source=DESKTOP-THSOQHE\\SQLEXPRESS;Initial Catalog=skincare;Integrated Security=True;Trust Server Certificate=True";
        private readonly int doctorId; // The logged-in doctor's ID

        public PrescribeMedicine(int doctorId)
        {
            InitializeComponent();
            this.doctorId = doctorId; // Store the doctor's ID for prescriptions
        }

        private void PrescribeMedicine_Load(object sender, EventArgs e)
        {
            LoadPatientsForDoctor(); // Load patients associated with the logged-in doctor
        }

        private void LoadPatientsForDoctor()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT DISTINCT u.UserID, u.Name
                        FROM Users u
                        INNER JOIN mappointment a ON u.UserID = a.UserID
                        WHERE a.DoctorID = @DoctorID AND u.Role = 'Customer'";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@DoctorID", doctorId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    cmbPatients.Items.Clear();
                    while (reader.Read())
                    {
                        cmbPatients.Items.Add(new ComboboxItem
                        {
                            Text = reader["Name"].ToString(),
                            Value = reader["UserID"].ToString()
                        });
                    }

                    cmbPatients.DisplayMember = "Text";
                    cmbPatients.ValueMember = "Value";
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading patients: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnPrescribe_Click(object sender, EventArgs e)
        {
            if (cmbPatients.SelectedItem == null)
            {
                MessageBox.Show("Please select a patient.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string patientID = ((ComboboxItem)cmbPatients.SelectedItem).Value;
            string medicineName = txtMedicineName.Text.Trim();
            string dosage = txtDosage.Text.Trim();

            // Validate user input
            if (string.IsNullOrEmpty(medicineName) || string.IsNullOrEmpty(dosage))
            {
                MessageBox.Show("All fields are required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Attempt to insert the prescription
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    string query = @"
                        INSERT INTO Prescriptions (PatientID, DoctorID, MedicineName, Dosage, PrescriptionDate)
                        VALUES (@PatientID, @DoctorID, @MedicineName, @Dosage, GETDATE())";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@PatientID", patientID);
                    cmd.Parameters.AddWithValue("@DoctorID", doctorId); // Use the logged-in doctor's ID
                    cmd.Parameters.AddWithValue("@MedicineName", medicineName);
                    cmd.Parameters.AddWithValue("@Dosage", dosage);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Medicine prescribed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    ClearFields(); // Clear input fields after successful submission
                }
                catch (SqlException ex)
                {
                    MessageBox.Show($"Database error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error prescribing medicine: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Method to clear input fields
        private void ClearFields()
        {
            cmbPatients.SelectedIndex = -1;
            txtMedicineName.Clear();
            txtDosage.Clear();
        }
    }

    // Custom class for ComboBox items
    public class ComboboxItem
    {
        public string Text { get; set; }
        public string Value { get; set; }
    }
}
