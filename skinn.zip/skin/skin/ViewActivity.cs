﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace skin
{
    public partial class ViewActivity : Form
    {
        private readonly string connectionString = "Data Source=DESKTOP-THSOQHE\\SQLEXPRESS;Initial Catalog=skincare;Integrated Security=True;Trust Server Certificate=True";

        public ViewActivity()
        {
            InitializeComponent();
        }

        private void ViewActivity_Load(object sender, EventArgs e)
        {
            // Load activity logs when the form is opened
            LoadActivityData();
        }

        // Load activity logs into the DataGridView
        private void LoadActivityData()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            ActivityID AS [ID], 
                            ActivityDescription AS [Description], 
                            ActivityDate AS [Date]
                        FROM ActivityLog
                        ORDER BY ActivityDate DESC";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvActivity.DataSource = dataTable; // Bind data to DataGridView
                    dgvActivity.AutoResizeColumns(); // Auto-adjust column sizes
                }
                catch (SqlException ex) when (ex.Message.Contains("Invalid object name"))
                {
                    MessageBox.Show("The ActivityLog table does not exist in the database. Please create the table or contact the administrator.", "Table Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading activity data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Add a button to refresh the activity log
        private void BtnRefresh_Click(object sender, EventArgs e)
        {
            LoadActivityData();
        }
    }
}
