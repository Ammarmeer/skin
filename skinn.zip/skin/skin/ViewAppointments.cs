﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace skin
{
    public partial class ViewAppointments : Form
    {
        private readonly string connectionString = "Data Source=DESKTOP-THSOQHE\\SQLEXPRESS;Initial Catalog=skincare;Integrated Security=True;Trust Server Certificate=True";
        private readonly int? customerId;
        private readonly int? doctorId;

        // Default constructor to load all appointments
        public ViewAppointments()
        {
            InitializeComponent();
            LoadAllAppointments();
        }

        // Overloaded constructor for customer or doctor
        public ViewAppointments(int? customerId = null, int? doctorId = null)
        {
            InitializeComponent();
            this.customerId = customerId;
            this.doctorId = doctorId;

            if (customerId.HasValue)
            {
                LoadCustomerAppointments(customerId.Value);
            }
            else if (doctorId.HasValue)
            {
                LoadDoctorAppointments(doctorId.Value);
            }
            else
            {
                LoadAllAppointments();
            }
        }

        // Load all appointments
        private void LoadAllAppointments()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            a.AppointmentID, 
                            u.Name AS UserName, 
                            d.Name AS DoctorName, 
                            a.AppointmentDate 
                        FROM 
                            mappointment a
                        INNER JOIN Users u ON a.UserID = u.UserID AND u.Role = 'Customer'
                        INNER JOIN Users d ON a.DoctorID = d.UserID AND d.Role = 'Doctor'
                        ORDER BY a.AppointmentDate DESC";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvAppointments.DataSource = dataTable; // Bind data to DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading all appointments: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Load appointments for a specific customer
        private void LoadCustomerAppointments(int customerId)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            a.AppointmentID, 
                            u.Name AS UserName, 
                            d.Name AS DoctorName, 
                            a.AppointmentDate 
                        FROM 
                            mappointment a
                        INNER JOIN Users u ON a.UserID = u.UserID AND u.Role = 'Customer'
                        INNER JOIN Users d ON a.DoctorID = d.UserID AND d.Role = 'Doctor'
                        WHERE u.UserID = @CustomerId
                        ORDER BY a.AppointmentDate DESC";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@CustomerId", customerId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvAppointments.DataSource = dataTable; // Bind data to DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading customer appointments: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Load appointments for a specific doctor
        private void LoadDoctorAppointments(int doctorId)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT 
                            a.AppointmentID, 
                            u.Name AS UserName, 
                            d.Name AS DoctorName, 
                            a.AppointmentDate 
                        FROM 
                            mappointment a
                        INNER JOIN Users u ON a.UserID = u.UserID AND u.Role = 'Customer'
                        INNER JOIN Users d ON a.DoctorID = d.UserID AND d.Role = 'Doctor'
                        WHERE d.UserID = @DoctorId
                        ORDER BY a.AppointmentDate DESC";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@DoctorId", doctorId);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgvAppointments.DataSource = dataTable; // Bind data to DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading doctor appointments: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
